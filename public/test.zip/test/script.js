const app = angular.module('desk', []);

app.controller('DeskCtrl', function ($scope, $http) {
	$scope.employees = [];
	$scope.customers = [];

	$http.get('employees.json').then(function (response) {
		let data = response.data;
		data.forEach(employee => $scope.employees.push(new Employee({
			full_name: employee.full_name,
			hire_date: new Date(employee.hire_date),
			e_salary: employee.salary
		})))
	}, function (response) {
		alert(response.data)
	});

	$http.get('customers.json').then(function (response) {
		let data = response.data;
		data.forEach(customer => $scope.customers.push(new Customer(customer)))
	}, function (response) {
		alert(response.data)
	});

	$scope.deleteEmployee = ($index) => {
		if ($scope.employees.length > 1)
			$scope.employees.splice($index, 1);
		else
			alert('The last employee cannot be deleted!')
	};

	$scope.customerModel = {
		name: '',
		contract_id: ''
	};

	$scope.addCustomer = () => {
		const customerData = $scope.customerModel;
		if (customerData.full_name !== '' && customerData.contract_id !== '') {
			$scope.customers.push(new Customer({
				full_name: customerData.name,
				contract_id: customerData.contract_id
			}));
			customerData.name = '';
			customerData.contract_id = '';
		} else {
			alert("Please complete all inputs!")
		}
	};
});

class Person {
	constructor(data) {
		this.full_name = data.full_name;
	}

	get name() {
		return this.full_name;
	}
}

class Employee extends Person {
	constructor(data) {
		super(data);
		this.full_name = data.full_name;
		this.hire_date = data.hire_date;
		this.e_salary = data.e_salary;
	}

	get hireDate() {
		return this.hire_date;
	}

	get salary() {
		return this.e_salary;
	}
}

class Customer extends Person {
	constructor(data) {
		super(data);
		this.full_name = data.full_name;
		this.contract_id = data.contract_id;
	}

	get contractId() {
		return this.contract_id;
	}
}